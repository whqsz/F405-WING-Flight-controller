# F405-WING-Flight-controller
----------------------------------------------------------
STM32F405RGT6 10-PWM OUT 6-UART Port

![view](https://github.com/whqsz/F405-WING-Flight-controller/blob/main/Image/3D1.png?raw=true "3D1 view")

![view](https://github.com/whqsz/F405-WING-Flight-controller/blob/main/Image/3D2.png?raw=true "3D2 view")
